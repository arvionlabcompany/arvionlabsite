import type { ReactNode } from 'react'

import { cx } from '../lib/cx'

/*
  Uma faixa de página, clara ou escura. As faixas se alternam na Home para dar
  ritmo à rolagem. Na faixa clara, as cores dos componentes se invertem sozinhas
  (ver .zone-light em styles.css).
*/
export function Zone({
  tone = 'dark',
  children,
  className,
  labelledBy,
  id,
}: {
  tone?: 'dark' | 'light'
  children: ReactNode
  className?: string
  labelledBy?: string
  id?: string
}) {
  return (
    <section id={id} aria-labelledby={labelledBy} className={cx('relative isolate overflow-hidden', tone === 'light' ? 'zone-light' : 'bg-bg text-fg', className)}>
      {children}
    </section>
  )
}
