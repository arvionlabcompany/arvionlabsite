import { Clock, PenTool, Users } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

import { Container } from '../components/Container'
import { Reveal } from '../components/Reveal'
import { SectionHeading } from '../components/Typography'
import { Zone } from '../components/Zone'
import { why } from '../content'

const icons: Record<string, LucideIcon> = { team: Users, prototype: PenTool, volume: Clock }

/** Faixa escura: por que escolher a ARVION Lab. */
export function WhyArvion() {
  return (
    <Zone tone="dark" labelledBy="why-title" className="py-20 sm:py-28">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(45%_60%_at_100%_0%,rgba(217,70,239,0.2),transparent)]" aria-hidden />
      <Container size="xl">
        <Reveal>
          <SectionHeading id="why-title" title={why.title} />
        </Reveal>
        <ul className="mx-auto mt-14 grid max-w-[1100px] gap-4 md:grid-cols-3">
          {why.cards.map((c, i) => {
            const Icon = icons[c.kind] ?? Users
            return (
              <Reveal as="li" key={c.title} delay={i * 0.08}>
                <article className="flex h-full flex-col gap-4 rounded-card bg-white/[0.04] p-7 ring-1 ring-inset ring-white/10">
                  <span className="grid size-12 place-items-center rounded-[16px] bg-[linear-gradient(135deg,#22d3ee,#8b5cf6)] text-black">
                    <Icon className="size-6" aria-hidden />
                  </span>
                  <h3 className="text-[22px] font-medium tracking-[-0.02em]">{c.title}</h3>
                  <p className="text-pretty text-[16px] leading-[1.55] text-muted">{c.body}</p>
                  {'stat' in c && c.stat ? (
                    <p className="mt-auto pt-2 text-[44px] font-medium leading-none tracking-[-0.04em]">
                      {c.stat}
                      <span className="ml-2 text-[18px] text-soft">{'unit' in c ? c.unit : ''}</span>
                    </p>
                  ) : null}
                </article>
              </Reveal>
            )
          })}
        </ul>
      </Container>
    </Zone>
  )
}
