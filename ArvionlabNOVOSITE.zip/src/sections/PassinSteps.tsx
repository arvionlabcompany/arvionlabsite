import { Container } from '../components/Container'
import { Reveal } from '../components/Reveal'
import { SectionHeading } from '../components/Typography'
import { Zone } from '../components/Zone'
import { passin } from '../content'

/** Faixa escura: como o PASSIN cut funciona, em três passos. */
export function PassinSteps() {
  return (
    <Zone tone="dark" labelledBy="steps-title" className="py-20 sm:py-28">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(50%_70%_at_0%_50%,rgba(139,92,246,0.22),transparent)]" aria-hidden />
      <Container size="xl" className="grid items-center gap-14 lg:grid-cols-[1fr_1.1fr] lg:gap-16">
        <div>
          <Reveal>
            <SectionHeading id="steps-title" align="left" eyebrow="Como funciona" title={['Do primeiro assinante', 'ao clube lucrando']} />
          </Reveal>
          <ol className="mt-10 flex flex-col gap-6">
            {passin.steps.map((s, i) => (
              <Reveal as="li" key={s.title} delay={i * 0.08}>
                <div className="flex gap-5">
                  <span className="round grid size-11 shrink-0 place-items-center rounded-full bg-[linear-gradient(135deg,#22d3ee,#8b5cf6)] text-[17px] font-semibold text-black">{i + 1}</span>
                  <div>
                    <h3 className="text-[20px] font-medium tracking-[-0.02em]">{s.title}</h3>
                    <p className="mt-1 max-w-[440px] text-pretty text-[16px] leading-[1.5] text-muted">{s.body}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </ol>
        </div>
        <Reveal>
          <div className="relative mx-auto w-full max-w-[620px]">
            <div className="absolute inset-[8%] -z-10 rounded-full bg-[radial-gradient(closest-side,rgba(34,211,238,0.3),transparent)]" aria-hidden />
            <img
              src="/images/passin-relatorios-agenda.webp"
              alt="PASSIN cut: relatórios de receita e agenda de atendimentos"
              width={900}
              height={900}
              loading="lazy"
              decoding="async"
              className="w-full rounded-[28px] ring-1 ring-inset ring-white/20 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.9)]"
            />
          </div>
        </Reveal>
      </Container>
    </Zone>
  )
}
