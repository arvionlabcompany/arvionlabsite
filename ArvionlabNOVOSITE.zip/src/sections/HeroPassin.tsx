import { motion } from 'motion/react'

import { buttonClass } from '../components/Button'
import { Badge } from '../components/Controls'
import { Container } from '../components/Container'
import { Zone } from '../components/Zone'
import { passin } from '../content'
import { Link } from '../lib/router'

const ease = [0.22, 1, 0.36, 1] as const

/** Topo da Home: o PASSIN cut, produto-chave da ARVION Products. */
export function HeroPassin() {
  return (
    <Zone tone="dark" labelledBy="hero-title">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(60%_60%_at_85%_30%,rgba(139,92,246,0.35),transparent),radial-gradient(50%_50%_at_10%_90%,rgba(34,211,238,0.14),transparent)]" aria-hidden />
      <Container size="xl" className="grid items-center gap-14 pb-20 pt-32 lg:grid-cols-[1fr_1.05fr] lg:gap-10 lg:pb-24 lg:pt-36">
        <div className="flex flex-col items-start gap-7">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease }}>
            <Badge tone="plasma" pulse>
              {passin.eyebrow}
            </Badge>
          </motion.div>
          <motion.h1
            id="hero-title"
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.08, ease }}
            className="display text-balance text-[42px] sm:text-[56px] lg:text-[64px]"
          >
            {passin.title.map((l) => (
              <span key={l} className="block bg-gradient-to-r from-white via-white to-fuchsia-200/80 bg-clip-text text-transparent">
                {l}
              </span>
            ))}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.16, ease }}
            className="max-w-[500px] text-pretty text-[18px] leading-[1.55] text-muted"
          >
            {passin.body}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.24, ease }}
            className="flex flex-wrap items-center gap-3"
          >
            <a href={passin.url} target="_blank" rel="noopener noreferrer" className={buttonClass('primary', 'lg')}>
              Conhecer o PASSIN cut
            </a>
            <Link href="/orcamento" className={buttonClass('secondary', 'lg')}>
              Pedir orçamento de site
            </Link>
          </motion.div>
          <p className="text-[14px] text-faint">Desenvolvido pela ARVION Lab · Rio de Janeiro</p>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.1, delay: 0.1, ease }}
          className="relative mx-auto w-full max-w-[600px] pb-10 pt-6 lg:pb-12"
        >
          <div className="absolute inset-[6%] -z-10 rounded-full bg-[radial-gradient(closest-side,rgba(139,92,246,0.5),transparent)]" aria-hidden />
          <img
            src="/images/art-passin.webp"
            alt="Painel do PASSIN cut com faturamento, assinantes e gráficos de desempenho"
            width={960}
            height={720}
            fetchPriority="high"
            decoding="async"
            className="relative w-full rounded-[24px] ring-1 ring-inset ring-white/20 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.9)]"
          />
          <img
            src="/images/art-passin-assinantes.webp"
            alt="Tela de assinantes do PASSIN cut, com plano, vencimento e cobrança"
            width={960}
            height={645}
            loading="lazy"
            decoding="async"
            className="absolute -bottom-2 -left-2 w-[52%] rounded-[18px] ring-1 ring-inset ring-white/25 shadow-[0_30px_60px_-20px_rgba(0,0,0,0.9)] sm:-left-8"
          />
          <img
            src="/images/art-passin-agenda.webp"
            alt="Tela de agenda do PASSIN cut, com horários e status de atendimento"
            width={960}
            height={621}
            loading="lazy"
            decoding="async"
            className="absolute -right-1 top-0 w-[44%] rounded-[18px] ring-1 ring-inset ring-white/25 shadow-[0_30px_60px_-20px_rgba(0,0,0,0.9)] sm:-right-6"
          />
        </motion.div>
      </Container>
    </Zone>
  )
}
