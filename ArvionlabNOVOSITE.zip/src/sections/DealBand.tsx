import { Container } from '../components/Container'
import { Reveal } from '../components/Reveal'
import { Zone } from '../components/Zone'
import { hero } from '../content'
import { useSiteText } from '../lib/os'
import { Link } from '../lib/router'

/*
  Faixa clara com um painel escuro: a promoção do mês (o texto vem do OS, aba Site).
  Dentro da faixa clara as cores se invertem, por isso o painel usa cores literais.
*/
export function DealBand() {
  const eyebrow = useSiteText('hero.eyebrow', hero.eyebrow)
  return (
    <Zone tone="light" labelledBy="deal-title" className="py-16 sm:py-20">
      <Container size="xl">
        <Reveal>
          <div className="relative overflow-hidden rounded-panel bg-[linear-gradient(120deg,#0b1230,#2a1070_55%,#6d28d9)] p-8 sm:p-12">
            <div className="absolute -right-24 -top-24 size-[360px] rounded-full bg-[radial-gradient(closest-side,rgba(34,211,238,0.45),transparent)]" aria-hidden />
            <div className="relative grid items-center gap-8 lg:grid-cols-[1.5fr_1fr]">
              <div>
                <p className="text-[14px] font-medium text-[#f5d0fe]">Promoção do mês</p>
                <h2 id="deal-title" className="display mt-2 text-balance text-[30px] text-[#ffffff] sm:text-[40px]">
                  {eyebrow}
                </h2>
                <p className="mt-3 max-w-[520px] text-[16px] leading-[1.55] text-[rgb(255_255_255/0.75)]">
                  Conte sobre o seu negócio e receba uma proposta sob medida para o seu site ou sistema.
                </p>
              </div>
              <div className="flex flex-wrap gap-3 lg:justify-end">
                <Link href="/orcamento" className="inline-flex h-[52px] items-center rounded-control bg-[#ffffff] px-7 text-[16px] font-medium text-[#0b1020] hover:bg-[#e2ebff]">
                  Solicitar orçamento
                </Link>
                <Link href="/planos" className="inline-flex h-[52px] items-center rounded-control bg-[rgb(255_255_255/0.12)] px-7 text-[16px] font-medium text-[#ffffff] ring-1 ring-inset ring-[rgb(255_255_255/0.3)] hover:bg-[rgb(255_255_255/0.2)]">
                  Ver planos
                </Link>
              </div>
            </div>
          </div>
        </Reveal>
      </Container>
    </Zone>
  )
}
