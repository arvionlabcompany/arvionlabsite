import { Container } from '../components/Container'
import { TextLink } from '../components/Button'
import { Reveal } from '../components/Reveal'
import { SectionHeading } from '../components/Typography'
import { Zone } from '../components/Zone'
import { audiences, hero } from '../content'
import { useSiteText } from '../lib/os'

/** Faixa clara: a ARVION Lab também faz sites e sistemas sob medida. */
export function WebSolutions() {
  const body = useSiteText('hero.body', hero.body)
  const items = audiences.filter((a) => a.id !== 'produtos')
  return (
    <Zone tone="light" labelledBy="web-title" className="py-20 sm:py-28">
      <Container size="xl">
        <Reveal>
          <SectionHeading id="web-title" eyebrow="ARVION Web e ARVION Solutions" title={['Também desenvolvemos', 'sites e sistemas sob medida']} body={body} />
        </Reveal>
        <ul className="mx-auto mt-14 grid max-w-[1000px] gap-6 md:grid-cols-2">
          {items.map((a, i) => (
            <Reveal as="li" key={a.id} delay={i * 0.08}>
              <article className="flex h-full flex-col gap-5 rounded-card bg-surface p-5 ring-1 ring-inset ring-white/10 shadow-[0_24px_50px_-34px_rgba(11,16,32,0.35)]">
                <img
                  src={a.image}
                  alt={a.imageAlt}
                  width={480}
                  height={360}
                  loading="lazy"
                  decoding="async"
                  className="aspect-[4/3] w-full rounded-[20px] object-cover ring-1 ring-inset ring-white/10"
                />
                <div className="flex flex-1 flex-col items-start gap-2 px-1 pb-1">
                  <h3 className="text-[22px] font-medium tracking-[-0.02em]">{a.title}</h3>
                  <p className="text-pretty text-[16px] leading-[1.5] text-muted">{a.body}</p>
                  <TextLink href={a.href} className="mt-auto pt-2">
                    Solicitar orçamento
                  </TextLink>
                </div>
              </article>
            </Reveal>
          ))}
        </ul>
        <div className="mt-8 flex justify-center">
          <TextLink href="/projetos" tone="muted">
            Ver todos os projetos
          </TextLink>
        </div>
      </Container>
    </Zone>
  )
}
