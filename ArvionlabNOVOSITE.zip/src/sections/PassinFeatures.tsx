import { Calculator, CalendarDays, ChartColumn, FileText, LayoutDashboard, Link2, Settings, Users } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

import { Container } from '../components/Container'
import { Reveal } from '../components/Reveal'
import { SectionHeading } from '../components/Typography'
import { Zone } from '../components/Zone'
import { passin } from '../content'

const icons: Record<(typeof passin.features)[number]['icon'], LucideIcon> = {
  painel: LayoutDashboard,
  assinantes: Users,
  agenda: CalendarDays,
  faturas: FileText,
  relatorios: ChartColumn,
  clube: Link2,
  calculadora: Calculator,
  config: Settings,
}

/** Faixa clara: tudo o que o PASSIN cut faz. */
export function PassinFeatures() {
  return (
    <Zone tone="light" labelledBy="features-title" className="py-20 sm:py-28">
      <Container size="xl">
        <Reveal>
          <SectionHeading
            id="features-title"
            eyebrow="Todas as ferramentas para a sua barbearia"
            title={['Tudo o que você precisa', 'para gerir o seu clube']}
            body="Do cadastro do assinante à cobrança e aos relatórios, o PASSIN cut reúne a rotina da barbearia em um só lugar."
          />
        </Reveal>
        <ul className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {passin.features.map((f, i) => {
            const Icon = icons[f.icon]
            return (
              <Reveal as="li" key={f.title} delay={(i % 4) * 0.06}>
                <div className="flex h-full flex-col gap-3 rounded-card bg-surface p-6 ring-1 ring-inset ring-white/10 shadow-[0_24px_50px_-34px_rgba(11,16,32,0.35)]">
                  <span className="grid size-11 place-items-center rounded-[14px] bg-[linear-gradient(135deg,#22d3ee,#8b5cf6)] text-black">
                    <Icon className="size-5" aria-hidden />
                  </span>
                  <h3 className="text-[18px] font-medium tracking-[-0.02em]">{f.title}</h3>
                  <p className="text-pretty text-[15px] leading-[1.5] text-muted">{f.body}</p>
                </div>
              </Reveal>
            )
          })}
        </ul>
      </Container>
    </Zone>
  )
}
