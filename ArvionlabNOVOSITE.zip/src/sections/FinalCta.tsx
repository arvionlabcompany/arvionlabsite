import { BrandStage } from '../components/BrandStage'
import { ButtonLink } from '../components/Button'
import { Container } from '../components/Container'
import { Reveal } from '../components/Reveal'
import { Zone } from '../components/Zone'
import { brand } from '../content'

/** Faixa escura final: convite para falar com a ARVION Lab, com a logo animada. */
export function FinalCta() {
  return (
    <Zone tone="dark" labelledBy="cta-title" className="py-20 sm:py-28">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(60%_80%_at_50%_100%,rgba(139,92,246,0.3),transparent)]" aria-hidden />
      <Container size="xl" className="grid items-center gap-12 lg:grid-cols-[1.1fr_1fr]">
        <Reveal>
          <div className="flex flex-col items-start gap-5">
            <h2 id="cta-title" className="display text-balance text-[38px] sm:text-[52px]">
              <span className="block">Vamos construir</span>
              <span className="block">o seu projeto?</span>
            </h2>
            <p className="max-w-[460px] text-pretty text-[18px] leading-[1.55] text-muted">
              Fale direto com quem desenvolve. Conte o que você precisa e receba uma proposta pelo WhatsApp ou pelo formulário.
            </p>
            <div className="flex flex-wrap gap-3">
              <ButtonLink href="/orcamento" size="lg">
                Solicitar orçamento
              </ButtonLink>
              <a href={brand.whatsappUrl} target="_blank" rel="noopener noreferrer" className="inline-flex h-[52px] items-center rounded-control bg-white/[0.08] px-7 text-[16px] font-medium text-white ring-1 ring-inset ring-white/15 hover:bg-white/[0.14]">
                WhatsApp {brand.whatsapp}
              </a>
            </div>
          </div>
        </Reveal>
        <BrandStage className="max-w-[460px]" />
      </Container>
    </Zone>
  )
}
