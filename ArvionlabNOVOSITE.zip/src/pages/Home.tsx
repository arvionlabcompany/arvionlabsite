import { DealBand } from '../sections/DealBand'
import { FinalCta } from '../sections/FinalCta'
import { HeroPassin } from '../sections/HeroPassin'
import { PassinFeatures } from '../sections/PassinFeatures'
import { PassinSteps } from '../sections/PassinSteps'
import { WebSolutions } from '../sections/WebSolutions'
import { WhyArvion } from '../sections/WhyArvion'

/* Faixas alternadas: escura, clara, escura, clara, escura, clara, escura. */
export function Home() {
  return (
    <>
      <HeroPassin />
      <PassinFeatures />
      <PassinSteps />
      <WebSolutions />
      <WhyArvion />
      <DealBand />
      <FinalCta />
    </>
  )
}
